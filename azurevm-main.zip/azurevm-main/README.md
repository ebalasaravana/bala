# AzureDevOpsPipelines-Tips

This demo shows how to deploy infrastructure into Azure using Terraform and Azure DevOps Yaml pipelines.

The video explaining the different steps is available here:

<img width="60%" src="https://i.ytimg.com/vi/ukmbiTSWU_M/maxresdefault.jpg">
<a href="https://youtu.be/ukmbiTSWU_M">https://youtu.be/ukmbiTSWU_M</a>
</img>
