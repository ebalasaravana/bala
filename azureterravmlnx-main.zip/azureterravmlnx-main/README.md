# terra-demo-vm
Deploy azure linux virtual machine using terraform

Related to terraform training, you can reach out us at vrk4opportunities@gmail.com

Subscribe to "VRK solutions" for more updates!!
